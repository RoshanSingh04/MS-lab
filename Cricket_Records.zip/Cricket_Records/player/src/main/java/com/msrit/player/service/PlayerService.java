package com.msrit.player.service;

import com.msrit.player.model.Player;
import com.msrit.player.repo.PlayerRepo;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.ArrayList;

@Service
public class PlayerService {
    private final PlayerRepo playerRepo;
    public PlayerService(PlayerRepo playerRepo) {
        this.playerRepo = playerRepo;
    }

    public Player getPlayerDetails(String id) {
        return playerRepo.findById(id).get();
    }
 
    public List<Player> getAllPlayerDetails(){
        return playerRepo.findAll();
    }

    public void createPlayer(Player player){
        playerRepo.save(player);
    }

    public void updatePlayer(Player player, String id){
        try{
            Player existPlayer = playerRepo.findById(id).get();
            existPlayer.setPlayer_id(player.getPlayer_id());
            existPlayer.setPlayer_name(player.getPlayer_name());
            existPlayer.setPlayer_age(player.getPlayer_age());
            existPlayer.setPlayer_runs(player.getPlayer_runs());
            existPlayer.setPlayer_highest(player.getPlayer_highest());
            existPlayer.setPlayer_capped(player.getPlayer_capped());
            existPlayer.setPlayer_cteam(player.getPlayer_cteam());
            playerRepo.save(existPlayer);
        }catch(Exception err){
            System.out.println("Error");
        }
        
    }

    public void deletePlayer(String id){
        playerRepo.deleteById(id);
    }
    
   
   public List<Player> capped(){
		List<Player> lst = new ArrayList<Player>();
		List<Player> newLst =new ArrayList<Player>();
		lst = playerRepo.findAll();
		for(int i=0;i<lst.size(); i++){
			Player temp = lst.get(i);
			//System.out.println(temp.getPlayer_capped());
			if( temp.getPlayer_capped().equals("YES")){
				newLst.add(temp);
			}
		}
		return newLst;
	} 
	
	public List<String> cappedTeam(String player_cTeam){
		List<Player> lst = new ArrayList<Player>();
		List<String> newLst = new ArrayList<String>();
		lst = playerRepo.findAll();
		for(int i=0;i<lst.size(); i++){
			Player temp = lst.get(i);
			if( temp.getPlayer_cteam().equals(player_cTeam) && temp.getPlayer_capped().equals("YES")){
				newLst.add(temp.getPlayer_id());
			}
		}
		return newLst;
    }
}
