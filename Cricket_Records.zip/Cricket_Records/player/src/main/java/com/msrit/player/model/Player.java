package com.msrit.player.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;

@Entity
@Table(name="players")
public class Player {
	//Primary key
    @Id
	private String player_id;
    @Column
	private String player_name;
    @Column
	private String player_age;
    @Column
	private String player_runs;
    @Column
	private String player_highest;
     @Column
	private String player_capped;
    @Column
	private String player_cteam;
 
	
	public Player(){}

	public Player(String string, String string1, String string2, String string3, String string4, String string5, String string6 ){
		player_id = string;
		player_name = string1;
		player_age = string2;
		player_runs = string3;
	        player_highest = string4;
	        player_capped = string5;
	        player_cteam = string6;
	}

	//id
    public String getPlayer_id() {
        return player_id;
    }

    public void setPlayer_id(String player_id) {
        this.player_id = player_id;
    }

	//name
    public String getPlayer_name() {
        return player_name;
    }
    public void setPlayer_name(String player_name) {
        this.player_name = player_name;
    }

	//age
    public String getPlayer_age() {
        return player_age;
    }

    public void setPlayer_age(String player_age) {
        this.player_age = player_age;
    }

	//runs
    public String getPlayer_runs() {
        return player_runs;
    }

    public void setPlayer_runs(String player_runs) {
        this.player_runs = player_runs;
    }

	//highest
    public String getPlayer_highest() {
        return player_highest;
    }

    public void setPlayer_highest(String player_highest) {
        this.player_highest = player_highest;
    }

	//team
    public String getPlayer_cteam() {
        return player_cteam;
    }

    public void setPlayer_cteam(String player_cteam) {
        this.player_cteam = player_cteam;
    }
    
    public String getPlayer_capped(){
    	return player_capped;
    }
    
    public void setPlayer_capped(String player_capped ){
    	this.player_capped = player_capped;
    }

}
