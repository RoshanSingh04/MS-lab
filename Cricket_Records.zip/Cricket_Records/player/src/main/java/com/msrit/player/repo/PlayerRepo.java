package com.msrit.player.repo;

import com.msrit.player.model.Player;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

@Repository
public interface PlayerRepo extends JpaRepository<Player, String> {

}
