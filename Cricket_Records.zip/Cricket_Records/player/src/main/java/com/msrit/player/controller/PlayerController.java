package com.msrit.player.controller;

import java.util.List;

import com.msrit.player.model.Player;
import com.msrit.player.service.PlayerService;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/players")
@RestController
public class PlayerController {
	private final PlayerService playerService;

	public PlayerController(PlayerService playerService) {
		this.playerService = playerService;
	}

	@GetMapping("/get/{id}")
	public Player getPlayer(@PathVariable String id) {
		return playerService.getPlayerDetails(id);
	}


	@GetMapping("/getAll")
	public List<Player> getAllPlayer(){
		return playerService.getAllPlayerDetails();
	}

	@PostMapping("/Create")
	public String createPlayer(@RequestBody Player player){
		playerService.createPlayer(player);
		return "Created";
	}

	@PutMapping("/update/{id}")
	public String updatePlayer(@RequestBody Player player, @PathVariable String id){
		playerService.updatePlayer(player, id);
		return "Updated";
	}

	@DeleteMapping("/delete/{id}")
	public String deletePlayer(@PathVariable String id){
		playerService.deletePlayer(id);
		return "Deleted";
	}
	
	@GetMapping("/capped")
	public List<Player> capped(){
		return playerService.capped();
	}
	
	@GetMapping("/capped/{cTeam}")
	public List<String> cappedTeam(@PathVariable String cTeam){
		return playerService.cappedTeam(cTeam);
	}
	
}
