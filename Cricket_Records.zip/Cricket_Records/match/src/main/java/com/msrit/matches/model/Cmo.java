package com.msrit.matches.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;

@Entity
@Table(name="matches")
public class Cmo {
    @Id
	private String match_id;
    @Column
	private String match_teams;
    @Column
	private String match_toss;
    @Column
	private String match_location;
    @Column 
	private String team1_score;
    @Column 
	private String team2_score;
    @Column
	private String match_result;
 
	
	public Cmo(){}

	public Cmo(String string, String string1, String string2, String string3, String string4, String string5, String string6 ){
		match_id = string;
		match_teams = string1;
    	    	match_toss = string2;
		match_location = string3;
		team1_score = string4;
		team2_score = string5;
		match_result = string6;
		
	}
	
	//ID
    public String getMatch_id() {
        return match_id;
    }

    public void setMatch_id(String match_id) {
        this.match_id = match_id;
    }

	//teams
    public String getMatch_teams() {
        return match_teams;
    }

    public void setMatch_teams(String match_teams) {
        this.match_teams = match_teams;
    }

	//toss
    public String getMatch_toss() {
        return match_toss;
    }

    public void setMatch_toss(String match_toss) {
        this.match_toss = match_toss;
    }
	
	//location
    public String getMatch_location() {
        return match_location;
    }

    public void setMatch_location(String match_location) {
        this.match_location = match_location;
    }
   
    	//team1_score
    public String getTeam1_score() {
        return team1_score;
    }

    public void setTeam1_score(String team1_score) {
        this.team1_score = team1_score;
    }
   
    	//team2_score
    public String getTeam2_score() {
        return team2_score;
    }

    public void setTeam2_score(String team2_score) {
        this.team2_score = team2_score;
    }
     
    	//result
    public String getMatch_result() {
        return match_result;
    }

    public void setMatch_result(String match_result) {
        this.match_result = match_result;
    }

}
