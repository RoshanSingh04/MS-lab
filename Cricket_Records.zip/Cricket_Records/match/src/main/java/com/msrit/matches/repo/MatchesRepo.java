package com.msrit.matches.repo;

import com.msrit.matches.model.Cmo;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

@Repository
public interface MatchesRepo extends JpaRepository<Cmo, String> {

}
