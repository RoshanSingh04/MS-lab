package com.msrit.matches.service;

import com.msrit.matches.model.Cmo;
import com.msrit.matches.repo.MatchesRepo;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MatchesService {
    private final MatchesRepo MatchesRepo;
    public MatchesService(MatchesRepo MatchesRepo) {
        this.MatchesRepo = MatchesRepo;
    }

    public Cmo getMatchDetails(String id) {
        return MatchesRepo.findById(id).get();
    }
 
    public List<Cmo> getAllMatchDetails(){
        return MatchesRepo.findAll();
    }

    public void createMatch(Cmo cmo){
        MatchesRepo.save(cmo);
    }

    public void updateMatch(Cmo cmo, String id){
        try{
            Cmo existCmo = MatchesRepo.findById(id).get();
            existCmo.setMatch_id(cmo.getMatch_id());
            existCmo.setMatch_teams(cmo.getMatch_teams());
            existCmo.setMatch_toss(cmo.getMatch_toss());
            existCmo.setMatch_location(cmo.getMatch_location());
            existCmo.setTeam1_score(cmo.getTeam1_score());
            existCmo.setTeam2_score(cmo.getTeam2_score());
	    existCmo.setMatch_result(cmo.getMatch_result());
            MatchesRepo.save(existCmo);
        }
        catch(Exception err){
            System.out.println("Error");
        }
        
    }

    public void deleteMatch(String id){
        MatchesRepo.deleteById(id);
    }
    
     public void deleteAllMatchDetails(){
        MatchesRepo.deleteAll();
    }
}
