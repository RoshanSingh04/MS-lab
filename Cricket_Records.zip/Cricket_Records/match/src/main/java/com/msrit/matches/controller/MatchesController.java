package com.msrit.matches.controller;

import java.util.List;

import com.msrit.matches.model.Cmo;
import com.msrit.matches.service.MatchesService;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/matches")
@RestController
public class MatchesController {
	private final MatchesService matchesService;

	public MatchesController(MatchesService matchesService) {
		this.matchesService = matchesService;
	}

	@GetMapping("/get/{id}")
	public Cmo getMatch(@PathVariable String id) {
		return matchesService.getMatchDetails(id);
	}


	@GetMapping("/getAll")
	public List<Cmo> getAllMatch(){
		return matchesService.getAllMatchDetails();
	}

	@PostMapping("/Create")
	public String createMatch(@RequestBody Cmo cmo){
		matchesService.createMatch(cmo);
		return "Created";
	}

	@PutMapping("/update/{id}")
	public String updateMatch(@RequestBody Cmo cmo, @PathVariable String id){
		matchesService.updateMatch(cmo, id);
		return "Updated";
	}

	@DeleteMapping("/delete/{id}")
	public String deleteMatch(@PathVariable String id){
		matchesService.deleteMatch(id);
		return "Deleted";
	}
	
	@DeleteMapping("/deleteAll")
	public String deleteAllMatchDetails(){
		matchesService.deleteAllMatchDetails();
		return "Deleted";
	}
}
